import account
class CurrentAccount(account.Account):

    def __init__(self, name: str, id: str,  initial: float, overdraft_limit: float) -> None:
        super().__init__(name, id, initial)
        # self._balance = initial
        self._overdraft_limit = overdraft_limit

    def withdraw(self, amt: int) -> None:
        # check overdraft_limit
        if self._balance - amt < self._overdraft_limit:
            return
        self._balance -= amt
        return
