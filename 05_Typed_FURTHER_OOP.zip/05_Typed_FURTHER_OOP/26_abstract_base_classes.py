from abc import * # ABC -> Abstract Base Class

class Account(ABC): # makes class a Metaclass which cannot be instantiated
    @abstractmethod
    def getType(self) -> None:
        pass

    def do_it(self) -> str:
        return "I'm doing it!"

class CurrentAccount(Account):
    def getType(self) -> None:
        print("CurrentAccount is an Account")

acc = CurrentAccount()
print(acc.getType())
print(acc.do_it())

# will error:
ac = Account()
print(ac.getType())
print(ac.do_it())

