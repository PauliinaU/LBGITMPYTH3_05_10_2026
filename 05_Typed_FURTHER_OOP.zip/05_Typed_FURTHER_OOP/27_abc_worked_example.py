from abc import ABC, abstractmethod

class Account(ABC):
    def __init__(self, owner: str, balance: int=0) -> None:
        self.owner = owner
        self.balance = balance

    def deposit(self, amount: int) -> None:
        self.balance += amount
    @abstractmethod
    def withdraw(self, amount: int) -> None:
        """Withdraw money from the account"""
        pass

class CurrentAccount(Account):
    def __init__(self, owner: str, balance: int=0, overdraft_limit: int=0) -> None:
        super().__init__(owner, balance)
        self.overdraft_limit = overdraft_limit
    def withdraw(self, amount: int) -> None:
        if self.balance - amount < -self.overdraft_limit:
            print(f"{self.owner}: Overdraft limit exceeded")
        else:
            self.balance -= amount
            print(f"{self.owner}: Withdrew £{amount}")

class HighInterestAccount(Account):
    MIN_BALANCE = 10000.0
    def __init__(self, owner: str, balance: int=10000.0, interest_rate: float=0.05) -> None:
        super().__init__(owner, balance)
        self.interest_rate = interest_rate
    def withdraw(self, amount: int) -> None:
        if self.balance - amount < self.MIN_BALANCE:
            print(f"{self.owner}: Cannot go below £{self.MIN_BALANCE}")
        else:
            self.balance -= amount
            print(f"{self.owner}: Withdrew £{amount}")
    def apply_interest(self) -> None:
        interest = self.balance * self.interest_rate
        self.balance += interest
        print(f"{self.owner}: Interest added £{interest:.2f}")


current = CurrentAccount("Peter", 100, overdraft_limit=50)
high_interest = HighInterestAccount("Alice", 15000, interest_rate=0.05)
current.withdraw(130)      # allowed (overdraft)
current.withdraw(50)       # exceeds overdraft
high_interest.withdraw(3000)   # blocked if it drops below 10,000
high_interest.apply_interest()

