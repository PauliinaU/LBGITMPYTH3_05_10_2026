from typing import Union

class Account:
    numCreated = 0


    def __init__(self, name: str="Anon", id: str="XXXXXXXX", initial_balance: float=0) -> None:
        self._balance = initial_balance
        self.name = name
        self.id = id
        Account.numCreated += 1


    def deposit(self, amt: Union[int, float]) -> None:
        self._balance += amt
        return


    def withdraw(self, amt: int) -> None:
        if self._balance - amt < 0:
            return
        self._balance -= amt
        return

    def setbalance(self, amt: int) -> None:
        if amt < 0:
            return
        self._balance = amt

    def getbalance(self) -> Union[int, float]:
        return self._balance

    def __str__(self) -> str:
        return f"Account {self.id} for {self.name} has a balance of £{self.balance}"

    balance = property(getbalance, setbalance)