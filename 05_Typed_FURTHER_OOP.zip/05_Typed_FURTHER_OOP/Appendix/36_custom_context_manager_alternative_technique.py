import sys
from types import TracebackType
from typing import Optional, Type

def add_ctxmgr(cls: Type["SomeClass"]) -> Type["SomeClass"]:
    def enterf(self) -> "SomeClass":
        return self

    def exitf(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> bool:
        if tb:
            print("Error from line:", tb.tb_lineno,
                  file=sys.stderr)
            return True
        else:
            return False

    cls.__enter__ = enterf
    cls.__exit__ = exitf

    return cls


@add_ctxmgr
class SomeClass:
    ...

with SomeClass(...) as var:
    print(var)
