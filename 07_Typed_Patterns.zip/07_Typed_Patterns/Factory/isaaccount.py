from account import Account
from typing import Union

class ISAAccount(Account):
    def __init__(self, account_number: str, balance: Union[int, float] = 0.0, max_balance: Union[int, float] = 20000.0) -> None:
        super().__init__(account_number, balance)
        self.max_balance = max_balance

    def deposit(self, amount: int) -> None:
        if amount <= 0:
            print("Invalid deposit amount")
            return

        if self.balance + amount <= self.max_balance:
            self.balance += amount
            print(f"Deposited {amount:.2f}")
        else:
            print("Deposit would exceed ISA limit")

    def withdraw(self, amount: int) -> None:
        if amount <= 0:
            print("Invalid withdrawal amount")
            return

        if amount <= self.balance:
            self.balance -= amount
            print(f"Withdrew {amount:.2f}")
        else:
            print("Insufficient funds")


