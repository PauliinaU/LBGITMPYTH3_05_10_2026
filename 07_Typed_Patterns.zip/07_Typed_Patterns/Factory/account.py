from abc import ABC, abstractmethod
from typing import Union

class Account(ABC):
    def __init__(self, account_number: str, balance: Union[int, float] = 0.0) -> None:
        self.account_number = account_number
        self.balance = balance

    @abstractmethod
    def deposit(self, amount: int) -> None:
        pass

    @abstractmethod
    def withdraw(self, amount: int) -> None:
        pass

    def __str__(self) -> str:
        return f"Account {self.account_number}, Balance: {self.balance:.2f}"

