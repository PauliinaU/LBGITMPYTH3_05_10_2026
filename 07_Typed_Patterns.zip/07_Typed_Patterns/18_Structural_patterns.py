from typing import Any

class proxy:
    def __init__(self, obj: Any) -> None:
        self.wrapped = obj

    def __getattr__(self, aname: str) -> Any:
        return getattr(self.wrapped, aname)
