from abc import abstractmethod
from file_system_receiver import FileSystem

class Command:
    @abstractmethod
    def execute(self) -> None:
        pass

# Concrete Commands
# Create Folder
class CreateFolderCommand(Command):
    def __init__(self, fs: FileSystem, path: str) -> None:
        self.fs = fs
        self.path = path

    def execute(self) -> None:
        self.fs.create_folder(self.path)

# Create File
class CreateFileCommand(Command):
    def __init__(self, fs: FileSystem, filename: str) -> None:
        self.fs = fs
        self.filename = filename

    def execute(self) -> None:
        self.fs.create_file(self.filename)

# Move File
class MoveFileCommand(Command):
    def __init__(self, fs: FileSystem, src: str, dest: str) -> None:
        self.fs = fs
        self.src = src
        self.dest = dest

    def execute(self) -> None:
        self.fs.move_file(self.src, self.dest)

# Rename File
class RenameFileCommand(Command):
    def __init__(self, fs: FileSystem, src: str, new_name: str) -> None:
        self.fs = fs
        self.src = src
        self.new_name = new_name

    def execute(self) -> None:
        self.fs.rename_file(self.src, self.new_name)