from command_interface_and_concrete_commands import CreateFileCommand, CreateFolderCommand, MoveFileCommand, RenameFileCommand
from typing import List, Union

class BatchProcessor:
    def __init__(self) -> None:
        self.commands: List[Union[CreateFileCommand, MoveFileCommand, CreateFolderCommand, RenameFileCommand]] = []

    def add_command(self, cmd: Union[CreateFileCommand, MoveFileCommand, CreateFolderCommand, RenameFileCommand]) -> None:
        self.commands.append(cmd)

    def run(self) -> None:
        for cmd in self.commands:
            cmd.execute()
