from __future__ import annotations
from observerinterface import Observer
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bankaccount import BankAccount

class SMSAlert(Observer):
    def update(self, account: BankAccount) -> None:
        print(f"[SMS] Alert: Balance is now £{account.balance}")

class EmailAlert(Observer):
    def update(self, account: BankAccount) -> None:
        print(f"[Email] Alert: Balance updated to £{account.balance}")