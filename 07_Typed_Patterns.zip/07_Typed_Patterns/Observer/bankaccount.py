from __future__ import annotations
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from concreteobservers import EmailAlert, SMSAlert

class BankAccount:
    def __init__(self, owner: str, balance: int) -> None:
        self.owner = owner
        self.balance = balance
        self._observers: list[Union[SMSAlert, EmailAlert]] = []  # AKA subscribers

    def attach(self, observer: Union[SMSAlert, EmailAlert]) -> None: # AKA subscribe
        self._observers.append(observer)

    def detach(self, observer: Union[EmailAlert, SMSAlert]) -> None: # AKA unsubscribe
        self._observers.remove(observer)

    def notify(self) -> None:
        for observer in self._observers:
            observer.update(self)

    def deposit(self, amount: int) -> None:
        self.balance += amount
        print(f"Deposited £{amount}. New balance = £{self.balance}")
        self.notify()

    def withdraw(self, amount: int) -> None:
        if amount > self.balance:
            print("Insufficient funds")
        else:
            self.balance -= amount
            print(f"Withdrew £{amount}. New balance = £{self.balance}")
            self.notify()