from __future__ import annotations
from abc import abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bankaccount import BankAccount

class Observer:
    @abstractmethod
    def update(self, account: BankAccount) -> None:
        pass
