# Command
from abc import abstractmethod
from bank_account_receiver import BankAccount

class Command:
    @abstractmethod
    def execute(self) -> None:
        pass


# Concrete Commands
class DepositCommand(Command):
    def __init__(self, account: BankAccount, amount: int) -> None:
        self.account = account
        self.amount = amount

    def execute(self) -> None:
        self.account.deposit(self.amount)

class WithdrawCommand(Command):
    def __init__(self, account: BankAccount, amount: int) -> None:
        self.account = account
        self.amount = amount

    def execute(self) -> None:
        self.account.withdraw(self.amount)
