# Invoker
from command_interface_and_concrete_commands import DepositCommand, WithdrawCommand
from typing import List, Union

class BankInvoker:
    def __init__(self) -> None:
        self._commands: List[Union[DepositCommand, WithdrawCommand]] = []

    def add_command(self, command: Union[DepositCommand, WithdrawCommand]) -> None:
        self._commands.append(command)

    def run(self) -> None:
        for command in self._commands:
            command.execute()
