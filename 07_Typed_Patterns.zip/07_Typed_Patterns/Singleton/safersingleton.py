
from typing import Dict, List, Type, Union

class BankLedger:
    _instance = None
    transactions: List[Dict[str, Union[str, int]]]

    # Must use __new__ and not __init__ because __init__ runs after an instance is already created.
    # To truly enforce a singleton, you must control instance creation, which is what __new__ does.
    def __new__(cls: Type["BankLedger"]) -> "BankLedger":
        if cls._instance is None:
            print("Creating the Bank Ledger instance...")
            cls._instance = super().__new__(cls)
            cls._instance.transactions = []
        return cls._instance

    def add_transaction(self, account_id: str, amount: int) -> None:
        self.transactions.append({
            "account_id": account_id,
            "amount": amount
        })

    def get_transactions(self) -> List[Dict[str, Union[str, int]]]:
        return self.transactions
