from typing import Dict, List, Union

_global_ledger = None  # module-level variable! Not good

class SloppyBankLedger:
    _global_ledger = None

    def __init__(self) -> None:
        self.transactions: List[Dict[str, Union[str, int, float]]] = []

    def add_transaction(self, account_id: str, amount: Union[int, float]) -> None:
        self.transactions.append({
            "account_id": account_id,
            "amount": amount
        })

    def get_transactions(self) -> List[Dict[str, Union[str, int, float]]]:
        return self.transactions

    @staticmethod
    def get_ledger() -> "SloppyBankLedger":
        global _global_ledger

        if _global_ledger is None:
            print("Creating sloppy global ledger...")
            _global_ledger = SloppyBankLedger()

        return _global_ledger